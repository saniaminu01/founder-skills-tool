# ⚡ Founder Skills Vault

AI-powered founder tools built with Claude. Includes 7 tools for content creation, lead generation, outreach, and more.

## Tools Included

- 🔥 Viral Content Generator
- 🧲 Lead Magnet Idea Generator
- 🏛️ Content Pillar Generator
- 🔍 LinkedIn Content Analyzer
- 🔄 LinkedIn → X Converter
- 💬 Warm DM Strategist
- 🎯 Lead Qualifier
- ✨ @theyisun Personalized Content Engine

---

## Deploy to Vercel (5 minutes)

### 1. Get your Anthropic API Key
- Go to [console.anthropic.com](https://console.anthropic.com)
- Click **API Keys → Create Key**
- Copy the key (you won't see it again)

### 2. Push to GitHub
- Create a new repo at [github.com/new](https://github.com/new)
- Upload all files from this folder maintaining the structure:
  ```
  /api/generate.js
  /public/index.html
  /public/yisun-content-generator.html
  /vercel.json
  ```

### 3. Deploy on Vercel
- Go to [vercel.com](https://vercel.com) → **Add New Project**
- Import your GitHub repo
- Click **Deploy** (don't change any settings yet)

### 4. Add your API Key (critical!)
- In your Vercel project → **Settings → Environment Variables**
- Add:
  - **Name:** `ANTHROPIC_API_KEY`
  - **Value:** `sk-ant-...` (your key from step 1)
- Click **Save**
- Go to **Deployments → Redeploy** (so the env var takes effect)

### 5. You're live! 🎉
- Your vault: `https://your-project.vercel.app`
- Yi Sun engine: `https://your-project.vercel.app/yisun-content-generator.html`

---

## Project Structure

```
founder-vault/
├── api/
│   └── generate.js        ← Serverless function (keeps API key secret)
├── public/
│   ├── index.html         ← Main Founder Skills Vault (7 tools)
│   └── yisun-content-generator.html  ← Personalized content engine
└── vercel.json            ← Vercel routing config
```

## How the Backend Works

All Claude API calls go through `/api/generate` — a serverless function running on Vercel's servers. Your `ANTHROPIC_API_KEY` is stored as a secret environment variable and **never exposed to the browser**. Users only ever talk to your `/api/generate` endpoint.

---

Built with Claude · Deployed on Vercel
